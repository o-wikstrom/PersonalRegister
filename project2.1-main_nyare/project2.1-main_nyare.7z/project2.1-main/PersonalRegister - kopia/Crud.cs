﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalRegister
{
    //public class Crud
    //{
    //    string info = " ";
    //    private string fname { get;  set; }
    //    private string ename { get;  set; }
    //    private string ID { get;  set; }
        

    //    public Crud(string fname, string ename, string iD)
    //    {
    //        this.fname = fname;
    //        this.ename = ename;
    //        ID = iD;
            
    //    }

        

    //    public string getArbetare() //inherate from abs
    //    {
    //        return info = "Arbetaren's Full namn är :  " + fname +" "+ ename + "\n" + " ID till användaren är : " + ID + "\n";
    //        //throw new NotImplementedException();

    //    }



    //    public string addArbetare(string fname, string ename, string ID)
    //    {
    //        Console.Write("Namn: ");
    //        fname = Console.ReadLine();
    //        Console.Write("Efternamn: ");
    //        ename = Console.ReadLine();
    //        Console.Write("ID: ");
    //        ID = Console.ReadLine();
            

    //        return getArbetare();
    //    }

    //    //public tabortArbetare()
    //    //{

    //    //}

    //    //public sokArbetare()
    //    //{

    //    //}

    //    //public uppdatera()
    //    //{

    //    //}

    //}
}
