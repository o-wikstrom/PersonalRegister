﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;

namespace PersonalRegister // Note: actual namespace depends on the project name.
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            int menyUI;
            bool mainMeny = true;
            User user = new User("","","");
            //ArrayList myList = new ArrayList();
            while (mainMeny)
            {

                Console.WriteLine("Vad vill du göra?");
                Console.WriteLine("Välj ett av dem fyra alternativen genom att skriva 1-4! \n");
                Console.WriteLine("1) Lägga till en arbetare");
                Console.WriteLine("2) Söka upp en arbetare");
                Console.WriteLine("3) Tar bort en person ur queue");
                Console.WriteLine("4) Binary search!");
                Console.WriteLine("5) Stäng av programmet!\n");
                Console.Write("Välj ett alternativ: ");

                menyUI = Convert.ToInt32(Console.ReadLine());

                switch(menyUI)
                {
                    case 1:
                        
                        user.addArbetare("","","");
                        break;

                    case 2:
                        
                        user.SearchArbetare("","","");
                        break;

                    case 3:

                        Queue<ArbetareAbs> queueArbetare = new Queue<ArbetareAbs>();

                        queueArbetare.Enqueue(new OverigaArbetare("Alexander", "Nordström", "80"));
                        queueArbetare.Enqueue(new ArbetsMyror("Aisha", "Hassan", "99"));
                        queueArbetare.Enqueue(new OverigaArbetare("Laza", "Gabriout", "90"));
                        queueArbetare.Enqueue(new ArbetsMyror("Oscar", "Wikström", "90"));
                        queueArbetare.Enqueue(new OverigaArbetare("Laza", "Gabriout", "90"));


                        foreach (var i in queueArbetare)
                        {
                            Console.WriteLine(i.getArbetare());

                        }

                        queueArbetare.Dequeue();

                        foreach (var i in queueArbetare)
                        {
                            Console.WriteLine(i.getArbetare());

                        }


                        break;
                    case 4:

                        List<ArbetareAbs> myList = new List<ArbetareAbs>();






                        myList.Add(new ArbetsMyror("Aisha", "Hassan", "996"));
                        myList.Add(new ArbetsMyror("Rikard", "Land", "696"));
                        myList.Add(new ArbetsMyror("Alice", "Hansson", "423"));
                        myList.Add(new ArbetsMyror("Titti", "Hane", "789"));

                        foreach (var i in myList)
                        {
                            Console.WriteLine(i.getArbetare());

                        }


                        ArbetareAbs SearchArbetare = new ArbetsMyror("Rikard", "Land", "696");
                        int index = myList.BinarySearch(SearchArbetare, new SearchArbetare());
                        Console.WriteLine($"\n{SearchArbetare.getName()} finns i index: {index}"); 


                        break;

                    case 5:
                        Environment.Exit(0);
                        break;
                }


            }
        }
    }
}
