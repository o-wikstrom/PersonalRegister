﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalRegister
{
    public class SearchArbetare : Comparer<ArbetareAbs>
    {
        public override int Compare(ArbetareAbs o1, ArbetareAbs o2)
        {
            
            if(o1.getId() == o2.getId())
            {
                return 0;
            }
            return -1;
        }
    }
}
