﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalRegister
{
    public class User : ArbetareAbs
    {
        string info = " ";
        bool sak = true;
        public User(string name, string efternamn, string id) : base(name, efternamn, id)
        {
        }
        List<ArbetareAbs> arbetare = new List<ArbetareAbs>();
        public string addArbetare(string name, string efternamn, string id)
        {
            

            
            while (sak)
            {
                Console.Write("Namn: ");
                name = Console.ReadLine();
                Console.Write("Efternamn: ");
                efternamn = Console.ReadLine();
                Console.Write("ID: ");
                id = Console.ReadLine();
                //birth = DateTime.Now;
                arbetare.Add(new ArbetsMyror(name, efternamn, id));
                Console.WriteLine("Vill du lägga till en till person? Y/N Y = Yes, N = No");
                string input = Console.ReadLine();
                string toUpper = input.ToUpper();
                if (toUpper == "Y")
                {
                    sak = true;
                }
                else if (toUpper == "N")
                {
                    break;
                }
                

                
            }
            foreach (var i in arbetare)
            {
                Console.WriteLine(i.getArbetare());

            }
            return getArbetare();
            
        }
        public string SearchArbetare(string name, string efternamn, string id)
        {
            String sSearch;

            Console.WriteLine("Who do you want to find?");
            sSearch = Console.ReadLine();

            for (int icount = 0; icount < arbetare.Count; icount++)
            {
                if (arbetare[icount].getId().Equals(sSearch))
                {
                    Console.WriteLine("found it");
                    Console.WriteLine(arbetare[icount].getName() + " " + arbetare[icount].getEfternamn());
            
                }
            }
            return "";
        }
        //public string removeArbetare(string name, string efternamn, string id)
        //{
        //    String sSearch;

        //    Console.WriteLine("Who do you want to remove?");
        //    sSearch = Console.ReadLine();

        //    for (int icount = 0; icount < arbetare.Count; icount++)
        //    {
        //        if (arbetare[icount].getId().Equals(sSearch))
        //        {
        //            arbetare[icount].
        //            //arbetare[icount].getId().Remove(icount);
        //            Console.WriteLine("Removed the worker!");
        //        }
        //    }
        //    //foreach (var i in arbetare)
        //    //{
        //       // Console.WriteLine(i.getArbetare());

        //    //}

        //    return "";
        //}


        //public string removeArbetare(string name, string efternamn, string id)
        //{
        //    int indexfunnen = -1;
        //    Console.WriteLine("Vilken arbetare vill du ta bort? skriv in arbetarens ID:");

        //    string finnArbetareId = Console.ReadLine();

        //    int indexForstNullvarde = arbetare.Count;

        //    for (int i = 0; i < arbetare.Count; i++)
        //    {
        //        if(arbetare[i] != null)
        //        {
        //            if (arbetare[i].getId().Equals(finnArbetareId))
        //            {
        //                indexfunnen = i;
        //            }
        //        }
        //    }
        //    for (int i = 0; i < arbetare.Count; i++)
        //    {
        //        if (arbetare[i] == null)
        //        {
        //            indexForstNullvarde = i;
        //        }
        //        Console.WriteLine("Arbetaren med id:" + finnArbetareId + " har tagits bort!");
        //    }
        //    if (indexfunnen != 0)
        //    {
        //        arbetare[indexfunnen] = arbetare[indexfunnen - 1] = null;
        //    }





            //Console.Write("Namn: ");
            //name = Console.ReadLine();
            //Console.Write("Efternamn: ");
            //efternamn = Console.ReadLine();
            //Console.Write("ID: ");
            //id = Console.ReadLine();
            ////birth = DateTime.Now;
            //arbetare.Remove(new ArbetsMyror(name, efternamn, id));








            //string input = Console.ReadLine();
            //Console.Write(arbetare.Contains(new ArbetsMyror("","",input)));

            //foreach(var value in arbetare)
            //{
            //    if(value.Equals(input))
            //    {
            //    arbetare.Remove(new ArbetsMyror(name, efternamn, id));
            //    }
            //}

            //foreach (var i in arbetare)
            //{
            //    Console.WriteLine(i.getArbetare());

            //}



            //return getArbetare();
        //}

        public override string getArbetare()
        {
            return info = "Arbetaren's Full namn är :  " + getName() + " " + getEfternamn() + "\n" + " ID till användaren är : " + getId() + "\n";
        }

        public override string getEfternamn()
        {
            return efternamn;
        }

        public override string getId()
        {
            return Id;
        }

        public override string getName()
        {
            return name;
        }
    
    }
}

